<?php
$uid  = 'NHV.FML';
$email = '';
$pass = '';
$email2 = '';
$pass2 = '';
$email3 = '';
$pass3 = '';
$email4 = ' ';
$pass4 = ' ';
$email5 = ' ';
$pass5 = ' ';
$email6 = ' ';
$pass6 = ' ';
$email7 = ' ';
$pass7 = ' ';
$email8 = ' ';
$pass8 = ' ';
$email9 = ' ';
$pass9 = ' ';
$email10 = ' ';
$pass10 = ' ';
?>