<html>
<head>
<meta charset="utf-8">
<title>Curl Like - Admin Panel</title>
<link href="css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<style>
.box{
    width:800px;
    height:800px;
    padding:20px;
    margin:0 auto;
    position:relative;
}
</style>